Geared Brass
============

Author: piraker-grinor

Notes:
Geared is a pre-rendered 3D animated cursor for Linux. Complete set of 32x and 64x animated cursors made for Xfce desktop, not sure about others but they will probably work too. This cursor is likely better suited for light themes, but is still perfectly usable on dark themes.

Colour palette from Fallout 2. All assets are created by me.

This animated cursor set contains 22 cursors.

Installed by install.inf (13 files):
  - EWResize_32-48-64.ani (multisize: 32, 48, 64px)
  - AppStarting_32-48-64.ani (multisize: 32, 48, 64px)
  - Help_32-48-64.ani (multisize: 32, 48, 64px)
  - Move_32-48-64.ani (multisize: 32, 48, 64px)
  - NEResize_32-48-64.ani (multisize: 32, 48, 64px)
  - Link_1_32-48-64.ani (multisize: 32, 48, 64px)
  - NotAllowed_32-48-64.ani (multisize: 32, 48, 64px)
  - Normal_32-48-64.ani (multisize: 32, 48, 64px)
  - NSResize_32-48-64.ani (multisize: 32, 48, 64px)
  - NWResize_32-48-64.ani (multisize: 32, 48, 64px)
  - Text_32-48-64.ani (multisize: 32, 48, 64px)
  - Precision_32-48-64.ani (multisize: 32, 48, 64px)
  - Wait_32-48-64.ani (multisize: 32, 48, 64px)

Extras (9 files) — not installed automatically:
These are alternates and spare cursors included with the set. To use one,
copy it over the installed file it replaces, then re-apply the scheme in
Control Panel > Mouse > Pointers.
  - Link_32-48-64.ani (multisize: 32, 48, 64px)
  - Move_1_32-48-64.ani (multisize: 32, 48, 64px)
  - NotAllowed_1_32-48-64.ani (multisize: 32, 48, 64px)
  - alias_32-48-64.ani (multisize: 32, 48, 64px)
  - context-menu_32-48-64.ani (multisize: 32, 48, 64px)
  - copy_32-48-64.ani (multisize: 32, 48, 64px)
  - vertical-text_32-48-64.ani (multisize: 32, 48, 64px)
  - zoom-in_32-48-64.ani (multisize: 32, 48, 64px)
  - zoom-out_32-48-64.ani (multisize: 32, 48, 64px)

Installation:
  1. Right-click install.inf
  2. Select 'Install'
  3. Open Control Panel > Mouse > Pointers
  4. Select 'Geared Brass' from the Scheme dropdown

Downloaded from Cursors-4U.com
https://www.cursors-4u.com
