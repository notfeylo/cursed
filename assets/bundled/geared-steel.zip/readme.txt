Geared Steel Link
=================

Author: piraker-grinor

This animated cursor file can be used to customize your Windows cursor.

Files included:
  - Link_32-48-64.ani

Installation:
  1. Copy the cursor file to a folder (e.g., C:\Windows\Cursors\)
  2. Open Control Panel > Mouse > Pointers
  3. Click 'Browse' to select the cursor file

Downloaded from Cursors-4U.com
https://www.cursors-4u.com
